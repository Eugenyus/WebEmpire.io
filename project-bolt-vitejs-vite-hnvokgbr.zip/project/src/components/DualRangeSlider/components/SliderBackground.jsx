import React from 'react';

export default function SliderBackground() {
  return (
    <div className="slider-background"></div>
  );
}